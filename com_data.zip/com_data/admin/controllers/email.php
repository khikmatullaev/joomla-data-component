<?php
defined('_JEXEC') or die('Restricted access');


/**
 * The single email entity controller
 */
class DataControllerEmail extends JControllerForm
{
}
