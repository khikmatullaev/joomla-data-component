<?php
defined('_JEXEC') or die('Restricted access');


/**
 * Component Controller
 */
class DataController extends JControllerLegacy
{
    /**
     * The default view.
     *
     * @var    string
     */
    protected $default_view = 'emails';
}
